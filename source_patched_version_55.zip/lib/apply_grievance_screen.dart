import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tutorial_coach_mark/tutorial_coach_mark.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'services/api_service.dart';
import 'services/database_service.dart';
import 'services/otp_gate_service.dart';
import 'tour_guides/apply_grievance_tour.dart';
import 'help/apply_grievance_help.dart';
import 'utils/ulb_language_helper.dart';

class ApplyGrievanceScreen extends StatefulWidget {
  /// Grievance category auto-selected when the screen is opened from the
  /// Payment Details screen.
  static const String propertyTaxCategoryName =
      'Property Tax (House, Water and Sewerage)';

  /// Grievance sub category auto-selected along with
  /// [propertyTaxCategoryName].
  static const String assessmentSubCategoryName = 'Regarding Assessment';

  final String? preselectedPropertyId;

  /// When set, the matching grievance category is selected automatically once
  /// the category list is loaded.
  final String? preselectedCategoryName;

  /// When set, the matching sub category of [preselectedCategoryName] is
  /// selected automatically. Ignored if the category could not be matched.
  final String? preselectedSubCategoryName;

  const ApplyGrievanceScreen({
    super.key,
    this.preselectedPropertyId,
    this.preselectedCategoryName,
    this.preselectedSubCategoryName,
  });

  @override
  State<ApplyGrievanceScreen> createState() => _ApplyGrievanceScreenState();
}

class _ApplyGrievanceScreenState extends State<ApplyGrievanceScreen> {
  static const Color _primaryColor = Color(0xFFE67514);
  static const Color _backgroundColor = Color(0xFFF8F9FB);
  static const Color _surfaceColor = Colors.white;
  static const Color _softPrimaryColor = Color(0xFFFFF3E8);
  static const Color _borderColor = Color(0xFFE4E8F0);
  static const Color _textPrimaryColor = Color(0xFF111827);
  static const Color _hintColor = Color(0xFF6B7280);

  final _formKey = GlobalKey<FormState>();
  final ImagePicker _picker = ImagePicker();

  // Tour guide keys
  final _keyPropertySection = GlobalKey();
  final _keyPersonalSection = GlobalKey();
  final _keyLocationSection = GlobalKey();
  final _keyGrievanceSection = GlobalKey();
  final _keyPhotoSection = GlobalKey();
  final _keySubmitButton = GlobalKey();

  TutorialCoachMark? _tutorialCoachMark;
  File? _selectedImage;
  bool _isSubmitting = false;

  // Personal Info Controllers
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _fatherNameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _userEmailController = TextEditingController();

  // Location Details
  UlbData? _selectedUlb;
  ZoneData? _selectedZone;
  WardData? _selectedWard;
  MohallaData? _selectedMohalla;
  final TextEditingController _landmarkController = TextEditingController();

  // Grievance Details
  GrievanceCategory? _selectedCategory;
  GrievanceSubCategory? _selectedSubCategory;
  final TextEditingController _descriptionController = TextEditingController();

  final Completer<List<UlbData>> _ulbsCompleter = Completer();

  List<ZoneData> _zoneList = [];
  List<WardData> _wardList = [];
  List<MohallaData> _mohallaList = [];
  List<GrievanceCategory> _grievanceCategories = [];
  List<PropertyEntity> _savedProperties = [];
  PropertyEntity? _selectedProperty;

  bool _isLoadingUlbs = true;
  bool _isLoadingZones = false;
  bool _isLoadingWards = false;
  bool _isLoadingMohallas = false;
  bool _isLoadingCategories = true;

  @override
  void initState() {
    super.initState();
    _fetchUlbs();
    _fetchGrievanceCategories();
    _loadSavedProperties();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _autoStartTourIfFirstVisit(),
    );
  }

  Future<void> _autoStartTourIfFirstVisit() async {
    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool('tour_apply_grievance') ?? false;
    if (!seen && mounted) {
      await prefs.setBool('tour_apply_grievance', true);
      await _startTour();
    }
  }

  void _showTourSegment({
    required TargetFocus target,
    VoidCallback? onFinish,
  }) {
    _tutorialCoachMark = ApplyGrievanceTourGuide.createCoachMark(
      targets: [target],
      onAdvance: () => _tutorialCoachMark?.next(),
      onFinish: onFinish,
    )..show(context: context);
  }

  Future<void> _scrollToTourTarget(GlobalKey keyTarget) async {
    final targetContext = keyTarget.currentContext;
    if (targetContext == null) {
      return;
    }

    await Scrollable.ensureVisible(
      targetContext,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeInOut,
      alignment: 0.18,
    );
    await WidgetsBinding.instance.endOfFrame;
  }

  Future<void> _showTourStep(
    List<ApplyGrievanceTourStep> steps,
    int index,
  ) async {
    if (!mounted || index >= steps.length) {
      return;
    }

    final step = steps[index];
    await _scrollToTourTarget(step.keyTarget);
    if (!mounted) {
      return;
    }

    _showTourSegment(
      target: step.target,
      onFinish: () {
        _showTourStep(steps, index + 1);
      },
    );
  }

  Future<void> _startTour() async {
    final steps = ApplyGrievanceTourGuide.buildSteps(
      propertySectionKey: _keyPropertySection,
      personalSectionKey: _keyPersonalSection,
      locationSectionKey: _keyLocationSection,
      grievanceSectionKey: _keyGrievanceSection,
      photoSectionKey: _keyPhotoSection,
      submitButtonKey: _keySubmitButton,
    );

    await _showTourStep(steps, 0);
  }

  Future<void> _loadSavedProperties() async {
    final properties = await DatabaseService.getAllProperties();
    setState(() {
      _savedProperties = properties;
    });

    if (widget.preselectedPropertyId != null) {
      final match = properties.where(
        (p) => p.propertyId == widget.preselectedPropertyId,
      );
      if (match.isNotEmpty) _onPropertySelected(match.first);
    } else if (properties.length == 1) {
      _onPropertySelected(properties.first);
    }
  }

  Future<void> _fetchUlbs() async {
    try {
      final ulbs = await ApiService.getUlbData();
      setState(() => _isLoadingUlbs = false);
      if (!_ulbsCompleter.isCompleted) _ulbsCompleter.complete(ulbs);
    } catch (e) {
      setState(() => _isLoadingUlbs = false);
      if (!_ulbsCompleter.isCompleted) _ulbsCompleter.complete([]);
    }
  }

  Future<void> _fetchGrievanceCategories() async {
    try {
      final categories = await ApiService.getGrievanceCategories();
      setState(() {
        _grievanceCategories = categories;
        _isLoadingCategories = false;
      });
      _applyPreselectedGrievanceType();
    } catch (e) {
      setState(() => _isLoadingCategories = false);
    }
  }

  /// Auto-selects the category / sub category requested by the caller
  /// (e.g. Payment Details → Apply Grievance). The user can still change them.
  void _applyPreselectedGrievanceType() {
    final categoryName = widget.preselectedCategoryName;
    if (!mounted || categoryName == null || _grievanceCategories.isEmpty) {
      return;
    }

    final category = _matchByName<GrievanceCategory>(
      _grievanceCategories,
      categoryName,
      (item) => item.serviceName,
    );
    if (category == null) return;

    final subCategoryName = widget.preselectedSubCategoryName;
    final subCategory = subCategoryName == null
        ? null
        : _matchByName<GrievanceSubCategory>(
            category.subCategories ?? const [],
            subCategoryName,
            (item) => item.subName,
          );

    setState(() {
      _selectedCategory = category;
      _selectedSubCategory = subCategory;
    });
  }

  /// Finds the entry whose name best matches [target]. Names come from the API
  /// so punctuation/spacing may differ: exact match is tried first, then
  /// containment, then a word overlap fallback.
  T? _matchByName<T>(
    List<T> items,
    String target,
    String? Function(T item) nameOf,
  ) {
    final normalizedTarget = _normalizeName(target);
    if (normalizedTarget.isEmpty) return null;

    for (final item in items) {
      if (_normalizeName(nameOf(item) ?? '') == normalizedTarget) return item;
    }

    for (final item in items) {
      final name = _normalizeName(nameOf(item) ?? '');
      if (name.isEmpty) continue;
      if (name.contains(normalizedTarget) || normalizedTarget.contains(name)) {
        return item;
      }
    }

    final targetWords = _nameWords(target);
    if (targetWords.isEmpty) return null;

    T? bestMatch;
    var bestScore = 1;
    for (final item in items) {
      final words = _nameWords(nameOf(item) ?? '');
      final score = words.where(targetWords.contains).length;
      if (score > bestScore) {
        bestScore = score;
        bestMatch = item;
      }
    }
    return bestMatch;
  }

  String _normalizeName(String value) =>
      value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');

  Set<String> _nameWords(String value) => value
      .toLowerCase()
      .split(RegExp(r'[^a-z0-9]+'))
      .where((word) => word.isNotEmpty && word != 'and')
      .toSet();

  Future<void> _fetchWards(String ulbId, String zoneId) async {
    setState(() => _isLoadingWards = true);
    try {
      final wards = await ApiService.getWardData(ulbId, zoneId);
      setState(() {
        _wardList = wards;
        _isLoadingWards = false;
      });
    } catch (e) {
      setState(() => _isLoadingWards = false);
    }
  }

  Future<void> _fetchMohallas(
    String ulbId,
    String zoneId,
    String wardId,
  ) async {
    setState(() => _isLoadingMohallas = true);
    try {
      final mohallas = await ApiService.getMohallaData(ulbId, zoneId, wardId);
      setState(() {
        _mohallaList = mohallas;
        _isLoadingMohallas = false;
      });
    } catch (e) {
      setState(() => _isLoadingMohallas = false);
    }
  }

  void _onPropertySelected(PropertyEntity property) {
    setState(() {
      _selectedProperty = property;
      _fullNameController.text = property.ownerName;
      _mobileController.text = property.phoneNumber;
      _emailController.text = property.email ?? "";
      _fatherNameController.text = property.fatherName ?? "N/A";
      _addressController.text = property.address ?? "N/A";
    });
    _autoFillLocation(property);
  }

  Future<void> _autoFillLocation(PropertyEntity property) async {
    final ulbId = property.ulbId;
    if (ulbId == null || ulbId.isEmpty) return;

    // ULB list load hone ka wait karo (agar abhi load ho rhi ho)
    final ulbs = await _ulbsCompleter.future;
    if (!mounted) return;

    // 1. ULB match karo ulbId se
    final matchedUlb = ulbs.where((u) => u.ulbId == ulbId).firstOrNull;
    if (matchedUlb == null) return;

    // 2. Zones fetch karo
    setState(() => _isLoadingZones = true);
    final List<ZoneData> zones;
    try {
      zones = await ApiService.getZoneData(ulbId);
    } catch (_) {
      setState(() => _isLoadingZones = false);
      return;
    }
    if (!mounted) return;

    // 3. Zone match karo name se (DB me zone name save h)
    final matchedZone = zones.where((z) => z.zoneName == property.zone).firstOrNull;
    setState(() {
      _selectedUlb = matchedUlb;
      _zoneList = zones;
      _isLoadingZones = false;
      _selectedZone = matchedZone;
      _selectedWard = null;
      _selectedMohalla = null;
      _wardList = [];
      _mohallaList = [];
    });
    if (matchedZone == null) return;

    // 4. Wards fetch karo
    setState(() => _isLoadingWards = true);
    final List<WardData> wards;
    try {
      wards = await ApiService.getWardData(ulbId, matchedZone.zoneId);
    } catch (_) {
      setState(() => _isLoadingWards = false);
      return;
    }
    if (!mounted) return;

    // 5. Ward match karo name se
    final matchedWard = wards.where((w) => w.wardName == property.ward).firstOrNull;
    setState(() {
      _wardList = wards;
      _isLoadingWards = false;
      _selectedWard = matchedWard;
      _selectedMohalla = null;
      _mohallaList = [];
    });
    if (matchedWard == null) return;

    // 6. Mohallas fetch karo
    setState(() => _isLoadingMohallas = true);
    final List<MohallaData> mohallas;
    try {
      mohallas = await ApiService.getMohallaData(ulbId, matchedZone.zoneId, matchedWard.wardId);
    } catch (_) {
      setState(() => _isLoadingMohallas = false);
      return;
    }
    if (!mounted) return;

    // 7. Mohalla match karo name se
    final matchedMohalla = mohallas.where((m) => m.mohallaName == property.mohalla).firstOrNull;
    setState(() {
      _mohallaList = mohallas;
      _isLoadingMohallas = false;
      _selectedMohalla = matchedMohalla;
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        final file = File(pickedFile.path);
        final fileSizeInBytes = await file.length();
        if (fileSizeInBytes > 200 * 1024) {
          final sizeInKB = (fileSizeInBytes / 1024).toStringAsFixed(1);
          if (mounted) {
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: Row(
                  children: [
                    const Icon(
                      Icons.error_outline,
                      color: Colors.red,
                      size: 28,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Image Too Large',
                      style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                content: Text(
                  'Selected image size is ${sizeInKB}KB which exceeds the 200KB limit.\n\nPlease select a smaller image.',
                  style: GoogleFonts.poppins(fontSize: 14),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      'OK',
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.bold,
                        color: _primaryColor,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }
          return;
        }
        setState(() {
          _selectedImage = file;
        });
      }
    } catch (_) {}
  }

  void _showImageSourceSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Select Image Source',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSourceOption(
                  icon: Icons.camera_alt_rounded,
                  label: 'Camera',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.camera);
                  },
                ),
                _buildSourceOption(
                  icon: Icons.photo_library_rounded,
                  label: 'Gallery',
                  onTap: () {
                    Navigator.pop(context);
                    _pickImage(ImageSource.gallery);
                  },
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSourceOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _softPrimaryColor,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: _primaryColor, size: 30),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: GoogleFonts.poppins(
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _showSelectionSheet({
    required String title,
    required List<String> items,
    required Function(int) onSelected,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) =>
          SelectionSheet(title: title, items: items, onSelected: onSelected),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        title: Text(
          'Apply Grievance',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: _primaryColor,
          ),
        ),
        backgroundColor: _surfaceColor,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: _primaryColor,
            size: 20,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline_rounded, color: _primaryColor),
            tooltip: 'Tour Guide',
            onPressed: _startTour,
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionTitle(
                    'Property Information',
                    helpTitle: ApplyGrievanceHelp.propertyInfoTitle,
                    helpMessage: ApplyGrievanceHelp.propertyInfoMessage,
                  ),
                  const SizedBox(height: 12),
                  _buildSelectableField(
                    key: _keyPropertySection,
                    hint: _selectedProperty?.propertyId ?? 'Select Property ID',
                    onTap: _savedProperties.isEmpty
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Property',
                            items: _savedProperties
                                .map((e) => e.propertyId)
                                .toList(),
                            onSelected: (index) =>
                                _onPropertySelected(_savedProperties[index]),
                          ),
                  ),
                  const SizedBox(height: 24),

                  _buildSectionTitle(
                    'Personal Information',
                    key: _keyPersonalSection,
                  ),
                  const SizedBox(height: 12),
                  _buildTextField(
                    'Full Name',
                    _fullNameController,
                    enabled: false,
                    isLanguageSensitive: true,
                  ),
                  _buildTextField(
                    'Mobile Number',
                    _mobileController,
                    keyboardType: TextInputType.phone,
                    enabled: false,
                  ),
                  _buildTextField(
                    'Father/Husband Name',
                    _fatherNameController,
                    enabled: false,
                    isLanguageSensitive: true,
                  ),
                  _buildTextField(
                    'Address',
                    _addressController,
                    maxLines: 2,
                    enabled: false,
                    isLanguageSensitive: true,
                  ),
                  _buildTextField(
                    'Email Address',
                    _userEmailController,
                    keyboardType: TextInputType.emailAddress,
                    isRequired: true,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter Email Address';
                      }
                      final emailRegex = RegExp(r'^[\w\.\-]+@([\w\-]+\.)+[\w\-]{2,}$');
                      if (!emailRegex.hasMatch(value.trim())) {
                        return 'Please enter a valid Email Address';
                      }
                      return null;
                    },
                  ),

                  const SizedBox(height: 24),
                  _buildSectionTitle(
                    'Location Details',
                    key: _keyLocationSection,
                    helpTitle: ApplyGrievanceHelp.locationDetailsTitle,
                    helpMessage: ApplyGrievanceHelp.locationDetailsMessage,
                  ),
                  const SizedBox(height: 12),

                  // Select ULB (read-only - user cannot change it)
                  _buildSelectableField(
                    label: 'ULB',
                    hint: _isLoadingUlbs
                        ? 'Loading ULBs...'
                        : (_selectedUlb?.toString() ?? 'Select ULB'),
                    onTap: null,
                  ),
                  const SizedBox(height: 16),

                  // Select Zone
                  _buildSelectableField(
                    label: 'Zone',
                    hint: _isLoadingZones
                        ? 'Loading Zones...'
                        : (_selectedZone?.zoneName ?? 'Select Zone'),
                    onTap: (_selectedUlb == null || _isLoadingZones)
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Zone',
                            items: _zoneList.map((e) => e.zoneName).toList(),
                            onSelected: (index) {
                              setState(() {
                                _selectedZone = _zoneList[index];
                                _selectedWard = null;
                                _selectedMohalla = null;
                                _wardList = [];
                                _mohallaList = [];
                              });
                              _fetchWards(
                                _selectedUlb!.ulbId!,
                                _selectedZone!.zoneId,
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 16),

                  // Select Ward
                  _buildSelectableField(
                    label: 'Ward',
                    hint: _isLoadingWards
                        ? 'Loading Wards...'
                        : (_selectedWard?.wardName ?? 'Select Ward'),
                    onTap: (_selectedZone == null || _isLoadingWards)
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Ward',
                            items: _wardList.map((e) => e.wardName).toList(),
                            onSelected: (index) {
                              setState(() {
                                _selectedWard = _wardList[index];
                                _selectedMohalla = null;
                                _mohallaList = [];
                              });
                              _fetchMohallas(
                                _selectedUlb!.ulbId!,
                                _selectedZone!.zoneId,
                                _selectedWard!.wardId,
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 16),

                  // Select Mohalla
                  _buildSelectableField(
                    label: 'Mohalla',
                    hint: _isLoadingMohallas
                        ? 'Loading Mohallas...'
                        : (_selectedMohalla?.mohallaName ?? 'Select Mohalla'),
                    onTap: (_selectedWard == null || _isLoadingMohallas)
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Mohalla',
                            items: _mohallaList
                                .map((e) => e.mohallaName)
                                .toList(),
                            onSelected: (index) {
                              setState(() {
                                _selectedMohalla = _mohallaList[index];
                              });
                            },
                          ),
                  ),
                  const SizedBox(height: 16),

                  _buildTextField(
                    'Enter Landmark',
                    _landmarkController,
                    isRequired: true,
                    maxLength: 200,
                    helpMessage: ApplyGrievanceHelp.landmarkMessage,
                    helpTitle: ApplyGrievanceHelp.landmarkTitle,
                  ),

                  const SizedBox(height: 24),
                  _buildSectionTitle(
                    'Grievance Details',
                    key: _keyGrievanceSection,
                    helpTitle: ApplyGrievanceHelp.grievanceDetailsTitle,
                    helpMessage: ApplyGrievanceHelp.grievanceDetailsMessage,
                  ),
                  const SizedBox(height: 12),

                  // Select Category
                  _buildSelectableField(
                    hint: _isLoadingCategories
                        ? 'Loading Categories...'
                        : (_selectedCategory?.serviceName ?? 'Select Category'),
                    onTap: _isLoadingCategories
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Category',
                            items: _grievanceCategories
                                .map((e) => e.serviceName ?? '')
                                .toList(),
                            onSelected: (index) {
                              setState(() {
                                _selectedCategory = _grievanceCategories[index];
                                _selectedSubCategory = null;
                              });
                            },
                          ),
                  ),
                  const SizedBox(height: 16),

                  // Select Sub Category
                  _buildSelectableField(
                    hint: _selectedCategory == null
                        ? 'Select Category First'
                        : (_selectedSubCategory?.subName ??
                              'Select Sub Category'),
                    onTap: _selectedCategory == null
                        ? null
                        : () => _showSelectionSheet(
                            title: 'Select Sub Category',
                            items: _selectedCategory!.subCategories!
                                .map((e) => e.subName ?? '')
                                .toList(),
                            onSelected: (index) {
                              setState(() {
                                _selectedSubCategory =
                                    _selectedCategory!.subCategories![index];
                              });
                            },
                          ),
                  ),
                  const SizedBox(height: 16),

                  _buildTextField(
                    'Grievance Description',
                    _descriptionController,
                    maxLines: 4,
                    maxLength: 500,
                    isRequired: true,
                    helpMessage: ApplyGrievanceHelp.descriptionMessage,
                    helpTitle: ApplyGrievanceHelp.descriptionTitle,
                  ),

                  const SizedBox(height: 16),
                  _buildSectionTitle(
                    'Upload Related Photo',
                    helpTitle: ApplyGrievanceHelp.photoTitle,
                    helpMessage: ApplyGrievanceHelp.photoMessage,
                  ),
                  const SizedBox(height: 12),
                  _buildPhotoUploadSection(key: _keyPhotoSection),

                  const SizedBox(height: 32),
                  SizedBox(
                    key: _keySubmitButton,
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : _submitGrievance,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _primaryColor,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: _isSubmitting
                          ? const CircularProgressIndicator(color: Colors.white)
                          : Text(
                              'Submit Grievance',
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
          if (_isSubmitting)
            Container(
              color: Colors.black.withValues(alpha: 0.3),
              child: const Center(
                child: CircularProgressIndicator(color: _primaryColor),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, {Key? key, String? helpTitle, String? helpMessage}) {
    if (helpMessage == null) {
      return Text(
        title,
        key: key,
        style: GoogleFonts.poppins(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: _primaryColor,
        ),
      );
    }
    return Row(
      key: key,
      children: [
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: _primaryColor,
          ),
        ),
        const SizedBox(width: 6),
        Builder(
          builder: (ctx) => GestureDetector(
            onTap: () => showDialog(
              context: ctx,
              builder: (_) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                title: Row(
                  children: [
                    const Icon(Icons.info_outline_rounded,
                        color: Color(0xFFE67514), size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        helpTitle ?? title,
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.w700, fontSize: 16),
                      ),
                    ),
                  ],
                ),
                content: Text(
                  helpMessage,
                  style: GoogleFonts.poppins(
                      fontSize: 13,
                      color: Colors.grey.shade700,
                      height: 1.6),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx),
                    child: Text('OK',
                        style: GoogleFonts.poppins(
                            color: const Color(0xFFE67514),
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
            child: const Icon(
              Icons.info_outline_rounded,
              color: Color(0xFFE67514),
              size: 16,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSelectableField({
    Key? key,
    required String hint,
    VoidCallback? onTap,
    String? label,
  }) {
    final field = GestureDetector(
      key: key,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: _surfaceColor,
          borderRadius: BorderRadius.circular(12),
          border: const Border.fromBorderSide(BorderSide(color: _borderColor)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                hint,
                style: GoogleFonts.poppins(
                  color: hint.contains('Select') || hint.contains('Loading')
                      ? _hintColor
                      : _textPrimaryColor,
                  fontSize: 14,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded, color: _hintColor),
          ],
        ),
      ),
    );

    if (label == null) return field;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 13,
            color: Colors.grey.shade700,
          ),
        ),
        const SizedBox(height: 6),
        field,
      ],
    );
  }

  Widget _buildTextField(
    String label,
    TextEditingController controller, {
    IconData? icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    int? maxLength,
    bool enabled = true,
    bool isRequired = false,
    bool isLanguageSensitive = false,
    String? helpTitle,
    String? helpMessage,
    String? Function(String?)? validator,
  }) {
    // Global cache ki bajay chuni hui property ka apna ulbLang use karo.
    final useKrutidev = !enabled &&
        isLanguageSensitive &&
        UlbLanguageHelper.isKrutidevValue(_selectedProperty?.ulbLang);
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        maxLength: maxLength,
        inputFormatters: [
          FilteringTextInputFormatter.deny(RegExp(r'[<>]')),
        ],
        enabled: enabled,
        style: useKrutidev
            ? TextStyle(
                fontFamily: UlbLanguageHelper.krutidevFontFamily,
                fontSize: 14,
                color: _hintColor,
              )
            : GoogleFonts.poppins(
                fontSize: 14,
                color: enabled ? _textPrimaryColor : _hintColor,
              ),
        validator: validator ??
            (isRequired
                ? (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter $label';
                    }
                    return null;
                  }
                : null),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: GoogleFonts.poppins(color: _hintColor, fontSize: 14),
          prefixIcon: icon != null
              ? Icon(icon, color: _primaryColor, size: 20)
              : null,
          suffixIcon: (helpMessage != null && enabled)
              ? Builder(
                  builder: (ctx) => IconButton(
                    icon: const Icon(
                      Icons.info_outline_rounded,
                      color: Color(0xFFE67514),
                      size: 18,
                    ),
                    onPressed: () => showDialog(
                      context: ctx,
                      builder: (_) => AlertDialog(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                        title: Row(
                          children: [
                            const Icon(Icons.info_outline_rounded,
                                color: Color(0xFFE67514), size: 20),
                            const SizedBox(width: 8),
                            Text(
                              helpTitle ?? label,
                              style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w700, fontSize: 16),
                            ),
                          ],
                        ),
                        content: Text(
                          helpMessage,
                          style: GoogleFonts.poppins(
                              fontSize: 13,
                              color: Colors.grey.shade700,
                              height: 1.6),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(ctx),
                            child: Text('OK',
                                style: GoogleFonts.poppins(
                                    color: const Color(0xFFE67514),
                                    fontWeight: FontWeight.w600)),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              : null,
          filled: true,
          fillColor: enabled ? _surfaceColor : const Color(0xFFF3F4F6),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _primaryColor),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red),
          ),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _borderColor),
          ),
        ),
      ),
    );
  }

  Widget _buildPhotoUploadSection({Key? key}) {
    return GestureDetector(
      key: key,
      onTap: _showImageSourceSheet,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _surfaceColor,
          borderRadius: BorderRadius.circular(12),
          border: const Border.fromBorderSide(BorderSide(color: _borderColor)),
        ),
        child: _selectedImage != null
            ? Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      _selectedImage!,
                      height: 200,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: GestureDetector(
                      onTap: () => setState(() => _selectedImage = null),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : Column(
                children: [
                  const Icon(
                    Icons.camera_alt_outlined,
                    color: _hintColor,
                    size: 40,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Upload Related Photo',
                    style: GoogleFonts.poppins(fontSize: 14, color: _hintColor),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '(Optional)',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: _hintColor.withValues(alpha: 0.8),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Future<void> _submitGrievance() async {
    // 1. Validate Form Fields (Edittexts)
    if (!_formKey.currentState!.validate()) return;

    // 2. Validate Custom Selectable Fields
    String? errorMessage;
    if (_selectedProperty == null) {
      errorMessage = 'Please select Property ID';
    } else if (_selectedUlb == null) {
      errorMessage = 'Please select ULB';
    } else if (_selectedZone == null) {
      errorMessage = 'Please select Zone';
    } else if (_selectedWard == null) {
      errorMessage = 'Please select Ward';
    } else if (_selectedMohalla == null) {
      errorMessage = 'Please select Mohalla';
    } else if (_selectedCategory == null) {
      errorMessage = 'Please select Category';
    } else if (_selectedSubCategory == null) {
      errorMessage = 'Please select Sub Category';
    }

    if (errorMessage != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final response = await OtpGateService.guard(
        call: () => ApiService.saveGrievance(
          ulbId: _selectedUlb!.ulbId!,
          zoneId: _selectedZone!.zoneId,
          wardId: _selectedWard!.wardId,
          mohallaId: _selectedMohalla!.mohallaId,
          categoryId: _selectedCategory!.serviceCode.toString(),
          subCategoryId: _selectedSubCategory!.subCatCode.toString(),
          landmark: _landmarkController.text.trim(),
          description: _descriptionController.text.trim(),
          name: _fullNameController.text.trim(),
          fatherName: _fatherNameController.text.trim(),
          mobileNo: _mobileController.text.trim(),
          email: _emailController.text.trim(),
          address: _addressController.text.trim(),
          propertyId: _selectedProperty!.propertyId,
          emailAddress: _userEmailController.text.trim(),
          imageFile: _selectedImage,
        ),
        responseCode: (r) => r.responseCode,
        propertyId: _selectedProperty!.propertyId,
        mobileNo: _mobileController.text.trim(),
      );

      if (mounted) {
        setState(() => _isSubmitting = false);
        if (response.success && response.data != null) {
          _showSuccessDialog(
            response.message.isNotEmpty
                ? response.message
                : 'Grievance Registered Successfully!',
            response.data,
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(response.message),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSubmitting = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              ApiService.getUserFriendlyErrorMessage(
                e,
                fallbackMessage:
                    'Unable to submit grievance right now. Please try again.',
              ),
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showSuccessDialog(String message, String? grievanceId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            const Icon(
              Icons.check_circle_outline_rounded,
              color: Colors.green,
              size: 28,
            ),
            const SizedBox(width: 10),
            Text(
              'Success',
              style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message, style: GoogleFonts.poppins()),
            if (grievanceId != null) ...[
              const SizedBox(height: 12),
              Text(
                'Grievance ID:',
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              Text(
                grievanceId,
                style: GoogleFonts.poppins(
                  color: _primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Go back from Apply Screen
            },
            child: Text(
              'OK',
              style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}

class SelectionSheet extends StatefulWidget {
  final String title;
  final List<String> items;
  final Function(int) onSelected;

  const SelectionSheet({
    super.key,
    required this.title,
    required this.items,
    required this.onSelected,
  });

  @override
  State<SelectionSheet> createState() => _SelectionSheetState();
}

class _SelectionSheetState extends State<SelectionSheet> {
  late List<String> filteredList;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    filteredList = widget.items;
  }

  void _filterSearch(String query) {
    setState(() {
      filteredList = widget.items
          .where((item) => item.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.title,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextField(
              controller: _searchController,
              onChanged: _filterSearch,
              maxLength: 100,
              inputFormatters: [
                FilteringTextInputFormatter.deny(RegExp(r'[<>]')),
              ],
              style: GoogleFonts.poppins(fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Search...',
                counterText: '',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Colors.grey.shade300),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ListView.separated(
              itemCount: filteredList.length,
              separatorBuilder: (context, index) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final item = filteredList[index];
                return ListTile(
                  title: Text(item, style: GoogleFonts.poppins(fontSize: 15)),
                  onTap: () {
                    final originalIndex = widget.items.indexOf(item);
                    widget.onSelected(originalIndex);
                    Navigator.pop(context);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
